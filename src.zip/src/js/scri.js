	var droppedItem="";
$(document).ready(function(){
	$('.main-container').load('MyLoading.html');

	var sampleData={};

	var urls=['https://reqres.in/api/users?page=2', 'https://reqres.in/api/users?page=2','https://reqres.in/api/users?page=2'];
	$.when(geturl(urls[0]),geturl(urls[1]),geturl(urls[2])).then(successcallback,failurecallback);

});




$(document).on('change','.show',function()
{
		if($(this).is(":checked")){
			$('.mainContainer').show();
		}
		else{
			$('.mainContainer').hide();
		}

});

function drag(ev){

	ev.dataTransfer.setData("text",ev.target.id)
}

function dragLeave(ev){

    ev.preventDefault();
    ev.target.innerHTML = document.getElementById(droppedItem).innerHTML;
}

function allowDrop(ev){
	ev.preventDefault();
	ev.target.innerHTML="";
}





function drop(ev){

	ev.preventDefault();
	var data = ev.dataTransfer.getData("text");
	ev.target.innerHTML = document.getElementById(data).innerHTML;
	$('#drag_item #'+data).css("display","none");
	if(droppedItem !=""){
	$('#drag_item #'+droppedItem).css("display","block");
		}
droppedItem = data;

	/*$(".list-unstyled li").css("display","block");
    ev.preventDefault();
      // console.log(ev.target);
    var data = ev.dataTransfer.getData("text");
        // console.log(document.getElementById(data));
    ev.target.innerHTML=document.getElementById(data).innerHTML;
    console.log(data);
    dragleave=data;
	$(".list-unstyled #"+data).css("display","none");
	// console.log($("#"+data).html());	

	if($("#"+data).html())
	{
	sampleData={"key":$("#"+data+" .key").html(),"value":$("#"+data+" .value").html()};
	}*/
}



$(document).on("click","#getButton",function(){

	$('.first').css("display","none");
	//$('.seconSection').hide();
	$('.thirdSection').show();

	$.ajax({
			url : "https://reqres.in/api/users?page=2",
			type : "GET",
			dataType : "json",
	

			 success: function(result) {

			 	for(i=0;i < result.data.length;i++){
  
					//$('<li class ="list-item"  id="drag'+i+'" draggable="true" ondragstart="drag(event)"/>').html('<span class="key"> '+result.data[i].id+' </span> <span class="value"> '+result.data[i].first_name+' </span>').appendTo('ul.list-unstyled');
					$('<li class="list-item" style="border:1px solid blue" draggable="true" id="drag'+i+'" ondragstart="drag(event)"/>').html('<span class="className"> '+result.data[i].id+'</span> <span class="className"> '+result.data[i].first_name+' </span>').appendTo('ul.list-unstyled');
			 	}

			 },
			 error: function(result){

			 }

	});
	

})

function geturl(url){
	return $.ajax({
		url : url,
		type : "GET",
		dataType : "json"

	});
}

function successcallback(data1,data2,data3){

for(i=0;i<data1[0].data.length;i++){
		$("#uniqueid").append($("<option/>",{
			value : data1[0].data[i].id,
			text : data1[0].data[i].id
		}));
	}
	
	


for(i=0;i<data1[0].data.length;i++){
	$("#firstname").append($("<option/>",{
		value: data1[0].data[i].first_name,
		text : data1[0].data[i].first_name

	}))
}	


for(i=0;i<data1[0].data.length;i++){
	$("#lastname").append($("<option/>",{
		value: data1[0].data[i].last_name,
		text : data1[0].data[i].last_name

	}))
}	


}



function failurecallback(data1,data2,data3){

}
