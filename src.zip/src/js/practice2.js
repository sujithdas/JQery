$(document).ready(function(){

$('.main-container').load('practice2.html');

	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		type:"GET",
		dataType : "json",

		success:function(result){

			for(i=0;i<result.data.length;i++){

					$('#uid').append($('<option>/',

					{
							value:result.data[i].id,
							text:result.data[i].id
					}));
			}

		},

		failure:function(result){

		}

	})


	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		dataType:"json",
		type:"GET",

		success:function(result){

			for(i=0;i<result.data.length;i++){

				$("#fname").append($('<option/>',{

					value:result.data[i].first_name,
					text:result.data[i].first_name

				}));
			}

		},
		failure:function(result){

		}
	})

	$.ajax({

		type:"GET",
		url:"https://reqres.in/api/users?page=2",
		dataType:"json",

		success:function(result){

			for(i=0;i<result.data.length;i++){

				$('#lname').append($('<option/>',{

					text:result.data[i].last_name,
					value:result.data[i].last_name
				}));
			}

		},
		failure:function(result){

		}
	})

});

$(document).on('click','#getQuote',function(){

	$('.firstSection').hide();
	$('.secondSection').hide();
	$('.thirdSection').show();


	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		type:"GET",
		dataType:"json",

			success:function(result){

				for(i=0;i<result.data.length;i++){

					$('<li draggable="true" style="border:1px solid blue" id="drag'+i+'" ondragstart="drag(event)"/>').html('<div> '+result.data[i].id+' '+result.data[i].first_name+'</div> ').appendTo('ul.list-unstyled')
				}

			},
			failure:function(result){


			}

	})
})
var droppable = "";

function drop(event){
	event.preventDefault();
	var data = event.dataTransfer.getData('text');
	event.target.innerHTML = document.getElementById(data).innerHTML;
	$('#testing #'+data).css('display','none');

	if(droppable != ""){
		$('#testing #'+droppable).css('display', 'block');
	}

	droppable = data;
}

function drag(event){

	event.dataTransfer.setData('text',event.target.id);
	
}



function allowdrop(event){
	event.preventDefault();



}

$(document).on('change','.show',function(){

	if($(this).is(":checked"))
{
	$('.firstSection').show();
	$('.secondSection').show();

}
else{
	$('.firstSection').hide();
	$('.secondSection').hide();
}
});